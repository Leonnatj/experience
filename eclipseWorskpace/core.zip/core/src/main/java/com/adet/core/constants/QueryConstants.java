package com.adet.core.constants;

public class QueryConstants {
	public static final String SELECT = "SELECT";
	public static final String FROM = "FROM";
}
