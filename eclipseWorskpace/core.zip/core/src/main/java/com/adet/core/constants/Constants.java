package com.adet.core.constants;

public class Constants {
	public static final String WHITESPACE = " ";
	public static final String COMMA = ",";
	public static final String NEW_LINE = "\n";
	public static final String PARENTHESIS_OPEN = "(";
	public static final String PARENTHESIS_CLOSE = ")";
	public static final String DOUBLE_QUOTE = "\"";
}
